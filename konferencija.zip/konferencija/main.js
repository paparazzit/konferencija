let menuBtn = document.querySelector(".burger");
let dropDown = document.querySelector(".nav-links");

menuBtn.addEventListener("click", () => {
	dropDown.classList.toggle("drop");
});

// show-hide

let adventures = document.querySelectorAll(".icon-wrapper div");
let advContents = document.querySelectorAll(".adv_content");
adventures.forEach((adventure) => {
	adventure.addEventListener("click", showHide);
});
function showHide() {
	let currentBtn = this.getAttribute("class");
	advContents.forEach((advContent) => {
		advContent.classList.remove("open");
		if (currentBtn === advContent.id) {
			advContent.classList.add("open");
		}
	});
}
